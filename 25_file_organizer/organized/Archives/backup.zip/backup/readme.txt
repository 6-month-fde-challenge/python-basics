A real ZIP archive, with two members.
